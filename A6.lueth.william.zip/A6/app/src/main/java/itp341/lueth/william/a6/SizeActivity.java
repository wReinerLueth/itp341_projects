package itp341.lueth.william.a6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class SizeActivity extends AppCompatActivity {
    // Instance Variables
    private TextView textSize;
    private Spinner spinnerSize;
    private Button buttonSave;

    private static final String TAG = "SizeActivity";

    private String size;
    private int completedPuzzles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_size);

        textSize = (TextView) findViewById(R.id.text_size);
        spinnerSize = (Spinner) findViewById(R.id.spinner_size);
        buttonSave = (Button) findViewById(R.id.button_save_size);

        completedPuzzles = getIntent().getIntExtra("completed", 0);

        setListeners();
    }

    private void setListeners(){
        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.array_size, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSize.setAdapter(adapter);

        spinnerSize.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(adapterView.getItemAtPosition(i).toString().equalsIgnoreCase(getResources().getString(R.string.size_small))) {
                    // Small

                    size = getResources().getString(R.string.size_small);
                }
                else if(adapterView.getItemAtPosition(i).toString().equalsIgnoreCase(getResources().getString(R.string.size_medium))) {
                    //Medium

                    size = getResources().getString(R.string.size_medium);
                }
                else{
                    // Big
                    size = getResources().getString(R.string.size_big);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SizeActivity.this, MainActivity.class);
                i.putExtra("completed", completedPuzzles);
                i.putExtra("aSize", size);
                Log.d(TAG, "Selected size: " + size);
                setResult(2, i);
                SizeActivity.this.finish();
            }
        });
    }
}
