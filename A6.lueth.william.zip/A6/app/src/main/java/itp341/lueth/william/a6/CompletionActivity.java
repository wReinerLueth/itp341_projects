package itp341.lueth.william.a6;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class CompletionActivity extends AppCompatActivity {
    // Instance Variable
    private TextView textSuccess;

    private static final String TAG = "CompletionActivity";

    private int completedPuzzles;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completion);

        textSuccess = (TextView) findViewById(R.id.text_complete);

        completedPuzzles = getIntent().getIntExtra("completed", 0);

        if(completedPuzzles == 3) textSuccess.setText(R.string.text_correct);
        else textSuccess.setText(R.string.text_incorrect);
    }
}
