package itp341.lueth.william.a6;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class ColorActivity extends AppCompatActivity {
    // Instance Variables
    private TextView textRed;
    private TextView textGreen;
    private TextView textBlue;
    private TextView textDisplay;
    private SeekBar seekRed;
    private SeekBar seekGreen;
    private SeekBar seekBlue;
    private Button buttonSave;

    private static final String TAG = "ColorActivity";

    private int valRed;
    private int valGreen;
    private int valBlue;

    private int completedPuzzles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);

        textRed = (TextView) findViewById(R.id.text_red);
        textGreen = (TextView) findViewById(R.id.text_green);
        textBlue = (TextView) findViewById(R.id.text_blue);
        textDisplay = (TextView) findViewById(R.id.display);
        seekRed = (SeekBar) findViewById(R.id.seek_red);
        seekGreen = (SeekBar) findViewById(R.id.seek_green);
        seekBlue = (SeekBar) findViewById(R.id.seek_blue);
        buttonSave = (Button) findViewById(R.id.button_save_color);

        getExtras();
        setListeners();
    }

    private void getExtras(){
        completedPuzzles = getIntent().getIntExtra("completed", 0);
    }

    private void setListeners() {
        seekRed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                valRed = i;
                textRed.setText("R: " + String.valueOf(i));
                displayChange(valRed, valGreen, valBlue);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        seekGreen.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                valGreen = i;
                textGreen.setText("G: " + String.valueOf(i));
                displayChange(valRed, valGreen, valBlue);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        seekBlue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                valBlue = i;
                textBlue.setText("R: " + String.valueOf(i));
                displayChange(valRed, valGreen, valBlue);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ColorActivity.this, MainActivity.class);
                i.putExtra("completed", completedPuzzles);
                i.putExtra("aRed", valRed);
                i.putExtra("aGreen", valGreen);
                i.putExtra("aBlue", valBlue);
                Log.d(TAG, valRed + "\n" + valGreen + "\n" + valBlue);
                setResult(1, i);
                ColorActivity.this.finish();
            }
        });
    }

    private void displayChange(int red, int green, int blue){
        textDisplay.setBackgroundColor(Color.rgb(red, green, blue));
    }

    // TODO: 10/2/2017
    // Need to make the preview change colors
}
