package itp341.lueth.william.a6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.jar.Attributes;

public class NameActivity extends AppCompatActivity {
    // Instance Variables
    private TextView textName;
    private EditText editName;
    private Button buttonSave;

    private static final String TAG = "NameActivity";

    private int completedPuzzles;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);

        textName = (TextView) findViewById(R.id.text_name);
        editName = (EditText) findViewById(R.id.edit_name);
        buttonSave = (Button) findViewById(R.id.button_save_name);

        completedPuzzles = getIntent().getIntExtra("completed", 0);

        setListeners();
    }

    private void setListeners(){
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name = editName.getText().toString();
                Intent i = new Intent(NameActivity.this, MainActivity.class);
                i.putExtra("completed", completedPuzzles);
                i.putExtra("aName", name);
                Log.d(TAG, "Selected name: " + name);
                setResult(3, i);
                NameActivity.this.finish();
            }
        });
    }
}
