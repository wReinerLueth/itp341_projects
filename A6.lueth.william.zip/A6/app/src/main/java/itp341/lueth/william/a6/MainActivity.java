package itp341.lueth.william.a6;

import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.ShareCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // Instance Variables
    private Button buttonColor;
    private Button buttonSize;
    private Button buttonName;
    private Button buttonSolve;
    private TextView textColor;
    private TextView textSize;
    private TextView textName;

    private static final String TAG = "MainActivity";

    public static final int COLOR_ANSWER_RED = 15;
    public static final int COLOR_ANSWER_GREEN = 230;
    public static final int COLOR_ANSWER_BLUE = 76;
    public static final String SIZE_ANSWER = "Medium";
    public static final String NAME_ANSWER = "Marty";

    public int completedPuzzles = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate() called");
        setContentView(R.layout.activity_main);

        buttonColor = (Button) findViewById(R.id.button_1);
        buttonSize = (Button) findViewById(R.id.button_2);
        buttonName = (Button) findViewById(R.id.button_3);
        buttonSolve = (Button) findViewById(R.id.button_solve);
        textColor = (TextView) findViewById(R.id.puzzle_1);
        textSize = (TextView) findViewById(R.id.puzzle_2);
        textName = (TextView) findViewById(R.id.puzzle_3);

        setListeners();
    }

    private void setListeners(){
        buttonColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Color Button clicked");
                Intent i = new Intent(MainActivity.this, ColorActivity.class);
                Log.d(TAG, "Color Activity Intent");

                i.putExtra("red", COLOR_ANSWER_RED);
                i.putExtra("green", COLOR_ANSWER_GREEN);
                i.putExtra("blue", COLOR_ANSWER_BLUE);
                i.putExtra("completed", completedPuzzles);

                startActivityForResult(i, 1);
            }
        });

        buttonSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Size Button clicked");
                Intent i = new Intent(MainActivity.this, SizeActivity.class);
                Log.d(TAG, "Size Activity Intent");

                i.putExtra("size", SIZE_ANSWER);
                i.putExtra("completed", completedPuzzles);

                startActivityForResult(i, 2);
            }
        });

        buttonName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Name Button clicked");
                Intent i = new Intent(MainActivity.this, NameActivity.class);
                Log.d(TAG, "Name Activity Intent");

                i.putExtra("name", NAME_ANSWER);
                i.putExtra("completed", completedPuzzles);

                startActivityForResult(i, 3);
            }
        });

        buttonSolve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Solve Button clicked");
                Intent i = new Intent(MainActivity.this, CompletionActivity.class);
                Log.d(TAG, "Solve Activity Intent");

                i.putExtra("completed", completedPuzzles);

                startActivityForResult(i, 0);
            }
        });
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    // TODO: 10/2/2017
    // could check hint for the method below

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (resultCode) {
            case 0:
                // Done
                break;
            case 1:
                // Color
                if((data.getIntExtra("aRed", 0) == COLOR_ANSWER_RED)
                        && (data.getIntExtra("aGreen", 0) == COLOR_ANSWER_GREEN)
                        && (data.getIntExtra("aBlue", 0) == COLOR_ANSWER_BLUE)
                        && completedPuzzles == 0){
                    textColor.setTextColor(Color.GREEN);
                    completedPuzzles++;
                }
                break;
            case 2:
                // Size
                if(data.getStringExtra("aSize").equalsIgnoreCase(SIZE_ANSWER)
                        && completedPuzzles == 1){
                    textSize.setTextColor(Color.GREEN);
                    completedPuzzles++;
                }
                break;
            case 3:
                //Name
                if(data.getStringExtra("aName").equalsIgnoreCase(NAME_ANSWER)
                        && completedPuzzles == 2){
                    textName.setTextColor(Color.GREEN);
                    completedPuzzles++;
                }
                break;
            default:
                // Idiot
                Log.e(TAG, "No valid data");
                break;
        }
    }
}
