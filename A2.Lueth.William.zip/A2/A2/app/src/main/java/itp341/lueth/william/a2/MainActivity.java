package itp341.lueth.william.a2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button gotButton;
    private Button lotrButton;
    private int gotCounter = 1;
    private int lotrCounter = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gotButton = (Button) findViewById(R.id.got_button);
        gotButton.setOnClickListener(this);
        lotrButton = (Button) findViewById(R.id.lotr_button);
        lotrButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.got_button:
                String gotStr = getResources().getString(R.string.gotPre) + " "
                        + Integer.toString(gotCounter)+ " ";
                if(gotCounter == 1) Toast.makeText(getApplicationContext(), gotStr + getResources().getString(R.string.post1), Toast.LENGTH_SHORT).show();
                else Toast.makeText(getApplicationContext(), gotStr + getResources().getString(R.string.post2), Toast.LENGTH_SHORT).show();
                gotCounter++;
                break;

            case R.id.lotr_button:
                String lotrStr = getResources().getString(R.string.lotrPre) + " "
                        + Integer.toString(lotrCounter)+ " ";
                if(lotrCounter == 1) Toast.makeText(getApplicationContext(), lotrStr + getResources().getString(R.string.post1), Toast.LENGTH_SHORT).show();
                else Toast.makeText(getApplicationContext(), lotrStr + getResources().getString(R.string.post2), Toast.LENGTH_SHORT).show();
                lotrCounter++;
                break;
        }
    }


    /*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gotButton = (Button) findViewById(R.id.got_button);
        lotrButton = (Button) findViewById(R.id.lotr_button);

        gotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // GoT Button
                String str = getResources().getString(R.string.gotPre) + " "
                        + Integer.toString(gotCounter)+ " ";
                if(gotCounter == 1) Toast.makeText(getApplicationContext(), str + getResources().getString(R.string.post1), Toast.LENGTH_SHORT).show();
                else Toast.makeText(getApplicationContext(), str + getResources().getString(R.string.post2), Toast.LENGTH_SHORT).show();
                gotCounter++;
            }
        });
        lotrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // LotR Button
                String str = getResources().getString(R.string.lotrPre) + " "
                        + Integer.toString(lotrCounter)+ " ";
                if(lotrCounter == 1) Toast.makeText(getApplicationContext(), str + getResources().getString(R.string.post1), Toast.LENGTH_SHORT).show();
                else Toast.makeText(getApplicationContext(), str + getResources().getString(R.string.post2), Toast.LENGTH_SHORT).show();
                lotrCounter++;
            }
        });
    }
    */
}
