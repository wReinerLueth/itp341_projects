package itp341.lueth.william.a3;

import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import static android.R.attr.id;

public class MainActivity extends AppCompatActivity {
    // Instance
    ImageView americanView;
    ImageView chineseView;
    ImageView indianView;
    ImageView italianView;
    ImageView middleEastView;
    ImageView brazillianView;

    int americanCounter = 1;
    int chineseCounter = 1;
    int indianCounter = 1;
    int italianCounter = 1;
    int middleEastCounter = 1;
    int brazillianCounter = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loadImages();
    }

    // Puling everything into ImageViews
    public void loadImages(){
        americanView = (ImageView) findViewById(R.id.american_food);
        chineseView = (ImageView) findViewById(R.id.chinese_food);
        indianView = (ImageView) findViewById(R.id.indian_food);
        italianView = (ImageView) findViewById(R.id.italian_food);
        middleEastView = (ImageView) findViewById(R.id.middle_east_food);
        brazillianView = (ImageView) findViewById(R.id.brazillian_food);
        Picasso.with(americanView.getContext()).load(getResources().getString(R.string.american)).fit().into(americanView);
        Picasso.with(americanView.getContext()).load(getResources().getString(R.string.chinese)).fit().into(chineseView);
        Picasso.with(americanView.getContext()).load(getResources().getString(R.string.indian)).fit().into(indianView);
        Picasso.with(americanView.getContext()).load(getResources().getString(R.string.italian)).fit().into(italianView);
        Picasso.with(americanView.getContext()).load(getResources().getString(R.string.middle_east)).fit().into(middleEastView);
        Picasso.with(americanView.getContext()).load(getResources().getString(R.string.brazillian)).fit().into(brazillianView);

        setClicks();
    }

    // An unfortunate way to get clicking to work
    public void setClicks(){
        americanView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String output = getResources().getString(R.string.select_text) + " "
                        + getResources().getString(R.string.american_text) + " "
                        + getResources().getString(R.string.select_text_food) + " "
                        + Integer.toString(americanCounter) + " ";
                if (americanCounter == 1)
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_one), Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_many), Toast.LENGTH_SHORT).show();
                americanCounter++;
            }
        });
        chineseView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String output = getResources().getString(R.string.select_text) + " "
                        + getResources().getString(R.string.chinese_text) + " "
                        + getResources().getString(R.string.select_text_food) + " "
                        + Integer.toString(chineseCounter) + " ";
                if (chineseCounter == 1)
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_one), Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_many), Toast.LENGTH_SHORT).show();
                chineseCounter++;
            }
        });
        indianView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String output = getResources().getString(R.string.select_text) + " "
                        + getResources().getString(R.string.indian_text) + " "
                        + getResources().getString(R.string.select_text_food) + " "
                        + Integer.toString(indianCounter) + " ";
                if (indianCounter == 1)
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_one), Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_many), Toast.LENGTH_SHORT).show();
                indianCounter++;
            }
        });
        italianView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String output = getResources().getString(R.string.select_text) + " "
                        + getResources().getString(R.string.italian_text) + " "
                        + getResources().getString(R.string.select_text_food) + " "
                        + Integer.toString(italianCounter) + " ";
                if (italianCounter == 1)
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_one), Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_many), Toast.LENGTH_SHORT).show();
                italianCounter++;
            }
        });
        middleEastView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String output = getResources().getString(R.string.select_text) + " "
                        + getResources().getString(R.string.middle_east_text) + " "
                        + getResources().getString(R.string.select_text_food) + " "
                        + Integer.toString(middleEastCounter) + " ";
                if (middleEastCounter == 1)
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_one), Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_many), Toast.LENGTH_SHORT).show();
                middleEastCounter++;
            }
        });
        brazillianView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String output = getResources().getString(R.string.select_text) + " "
                        + getResources().getString(R.string.brazillian_text) + " "
                        + getResources().getString(R.string.select_text_food) + " "
                        + Integer.toString(brazillianCounter) + " ";
                if (brazillianCounter == 1)
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_one), Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), output + getResources().getString(R.string.select_text_many), Toast.LENGTH_SHORT).show();
                brazillianCounter++;
            }
        });
    }

    // Orientation Saving

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putInt("american", americanCounter);
        savedInstanceState.putInt("chinese", chineseCounter);
        savedInstanceState.putInt("indian", indianCounter);
        savedInstanceState.putInt("italian", italianCounter);
        savedInstanceState.putInt("middleEast", middleEastCounter);
        savedInstanceState.putInt("brazillian", brazillianCounter);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        americanCounter = savedInstanceState.getInt("american");
        chineseCounter = savedInstanceState.getInt("chinese");
        indianCounter = savedInstanceState.getInt("indian");
        italianCounter = savedInstanceState.getInt("italian");
        middleEastCounter = savedInstanceState.getInt("middleEast");
        brazillianCounter = savedInstanceState.getInt("brazillian");
    }
}
