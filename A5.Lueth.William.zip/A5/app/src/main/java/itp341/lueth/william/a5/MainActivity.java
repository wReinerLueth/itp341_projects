package itp341.lueth.william.a5;

import android.icu.text.DecimalFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Instance Variables
    private TextView textBill;
    private TextView textPercent;
    private TextView textTip;
    private TextView textTotal;
    private TextView textSplit;
    private TextView textSplitYes;
    private TextView textSplitYesVal;
    private EditText editBill;
    private TextView textPercentProgress;
    private SeekBar seekPercent;
    private TextView textTipVal;
    private TextView textTotalVal;
    private Spinner spinnerSplit;

    public double billTotal;
    public double tipTotal;
    public double total;
    public double splitNum;

    public static final String TAG = MainActivity.class.getSimpleName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findWidgets();

        addListeners();
    }

    private void findWidgets(){
        textBill = (TextView) findViewById(R.id.bill_text);
        textPercent = (TextView) findViewById(R.id.percent_text);
        textTip = (TextView) findViewById(R.id.tip_text);
        textTotal = (TextView) findViewById(R.id.total_text);
        textSplit = (TextView) findViewById(R.id.split_text);
        textSplitYes = (TextView) findViewById(R.id.split_yes_text);
        textSplitYesVal = (TextView) findViewById(R.id.split_yes_amount);
        textPercentProgress = (TextView) findViewById(R.id.percent_num);
        textTipVal = (TextView) findViewById(R.id.tip_amount);
        textTotalVal = (TextView) findViewById(R.id.total_amount);
        editBill = (EditText) findViewById(R.id.bill_edit);
        seekPercent = (SeekBar) findViewById(R.id.percent_bar);
        spinnerSplit = (Spinner) findViewById(R.id.split_spinner);

        textSplitYes.setVisibility(View.GONE);
        textSplitYesVal.setVisibility(View.GONE);
    }

    private void addListeners(){
        editBill.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if((keyEvent.getAction() == KeyEvent.ACTION_DOWN) && (i == KeyEvent.KEYCODE_ENTER)){
                    billTotal = Double.parseDouble(editBill.getText().toString());
                    Log.d(TAG, "This is the answer " + editBill.getText().toString());
                    updateVals();
                    return true;
                }
                return false;
            }
        });

        seekPercent.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                textPercentProgress.setText(String.valueOf(i));
                updateVals();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        // TODO: 9/20/2017
        // Need spinner values added to spinner, show/hide split views

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner_split_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSplit.setAdapter(adapter);

        spinnerSplit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(adapterView.getItemAtPosition(i).toString().equalsIgnoreCase(getResources().getString(R.string.spinner_no))) {
                    textSplitYes.setVisibility(View.GONE);
                    textSplitYesVal.setVisibility(View.GONE);
                    updateVals();
                }
                else{
                    String temp = (String) adapterView.getItemAtPosition(i);
                    String steal = temp.substring(0, temp.indexOf(" "));

                    splitNum = Double.parseDouble(steal);
                    textSplitYes.setVisibility(View.VISIBLE);
                    textSplitYesVal.setVisibility(View.VISIBLE);
                    updateVals();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void updateVals(){
        double parsePercent = Double.parseDouble(textPercentProgress.getText().toString());

        tipTotal = billTotal * (parsePercent/100);
        total = billTotal + tipTotal;

        tipTotal = Math.ceil(tipTotal * 100)/100;
        total = Math.ceil(total * 100)/100;
        double splitVal = Math.ceil((total/splitNum) * 100)/100;

        textTipVal.setText("$" + tipTotal);
        textTotalVal.setText("$" + total);

        textSplitYesVal.setText("$" + splitVal);
    }
}
