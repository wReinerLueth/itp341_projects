package itp341.lueth.william.a9.Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by William Lueth on 10/30/2017.
 */

public class Movie {
    // Instance Variables
    private String mTitle;
    private String mDesc;
    private int mGenre;
    private List<String> mComments = new ArrayList<>();
    private String mLink;

    public Movie(){
        mTitle = "new Movie";
        mDesc = "Movie Description";
        mGenre = 3;
    }

    public Movie(String title, String desc, int genre, List comments){
        mTitle = title;
        mDesc = desc;
        mGenre = genre;
        mComments.addAll(comments);
    }

    public Movie(String title, String desc, int genre, List comments, String link){
        this(title, desc, genre, comments);
        mLink = link;
    }

    // Getters and Setters

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public String getDesc() {
        return mDesc;
    }

    public void setDesc(String mDesc) {
        this.mDesc = mDesc;
    }

    public int getGenre() {
        return mGenre;
    }

    public void setGenre(int mGenre) {
        this.mGenre = mGenre;
    }

    public List<String> getComments() {
        return mComments;
    }

    public void setComments(List<String> mComments) {
        this.mComments = mComments;
    }

    public String getLink() {
        return mLink;
    }

    public void setLink(String mLink) {
        this.mLink = mLink;
    }

    @Override
    public String toString() {
        return  "***** " + mTitle + " *****" + "\n" +
                "Description: " + mDesc + "\n" +
                "Genre: " + mGenre + "\n" +
                "Comments: " + mComments + "\n" +
                "URL: " + mLink;
    }
}
