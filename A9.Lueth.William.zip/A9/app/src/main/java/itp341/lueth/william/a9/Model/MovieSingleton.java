package itp341.lueth.william.a9.Model;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by William Lueth on 10/30/2017.
 */

public class MovieSingleton {
    // Instance
    private List<Movie> mMovies;
    private Context mContext;

    // Reference to itself
    private static MovieSingleton mySingleton;

    private MovieSingleton(Context c) {
        mContext = c;
        mMovies = new ArrayList<>();
        for (int i = 1; i < 10; i++) {
            Movie shop = new Movie();
            shop.setTitle("Movie " + i);
            mMovies.add(shop);
        }
    }

    public static MovieSingleton get(Context c){
        // if singleton doesn't exist, make one
        // otherwise don't
        if(mySingleton == null){
            mySingleton = new MovieSingleton(c);
        }
        return mySingleton;
    }

    public int getMovieQuant() {
        return mMovies.size();
    }

    public List<Movie> getMovieList(){
        return mMovies;
    }

    public Movie getMovieAtPosition(int index) {
        if(index >= 0 && index < mMovies.size()){
            return mMovies.get(index);
        }
        else{
            return null;
        }
    }

    public void addMovie(Movie mov){
        mMovies.add(mov);
    }

    public void removeMovie(int index){
        if(index >= 0 && index < mMovies.size()){
            mMovies.remove(index);
        }
    }

    public void addComment(int index, Movie mov, String comment){
        if(index >= 0 && index < mMovies.size() && mov != null){
            List<String> temp = mov.getComments();
            temp.add(comment);
            mov.setComments(temp);
            mMovies.set(index, mov);
        }
    }
}
