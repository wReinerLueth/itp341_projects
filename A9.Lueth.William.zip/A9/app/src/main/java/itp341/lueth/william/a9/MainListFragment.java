package itp341.lueth.william.a9;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.zip.Inflater;

import itp341.lueth.william.a9.Model.Movie;
import itp341.lueth.william.a9.Model.MovieSingleton;

/**
 * A simple {@link Fragment} subclass.
 */
public class MainListFragment extends android.support.v4.app.Fragment {
    // Instance
    private ListView listMain;
    private Button buttonAdd;

    private MovieListAdapter adapter;

    public static final String EXTRA_POSITION = "extra_position";

    public MainListFragment() {
        // Required empty public constructor
    }

    public static MainListFragment newInstance() {
        Bundle args = new Bundle();

        MainListFragment f = new MainListFragment();
        f.setArguments(args);

        return f;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_main, container, false);

        // find views
        listMain = (ListView) v.findViewById(R.id.listView);
        buttonAdd = (Button) v.findViewById(R.id.addButton);

        List<Movie> movies = MovieSingleton.get(getContext()).getMovieList();
        adapter = new MovieListAdapter(getContext(), R.layout.layout_list_movie, movies);
        listMain.setAdapter(adapter);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), CreateActivity.class);
                startActivityForResult(i, 0);
            }
        });

        return v;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == Activity.RESULT_OK){
            refresh();
        }
    }

    public void refresh(){
        adapter.notifyDataSetChanged();
    }

    // Adapter Code

    private class MovieListAdapter extends ArrayAdapter<Movie> {
        //do this every time
        public MovieListAdapter(Context c, int resID, List<Movie> movies){
            super(c, resID, movies);
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            // Step 1 -- inflate view (row) if necessary
            if(convertView == null){        // row has NEVER BEEN CREATED
                convertView = getActivity().getLayoutInflater().inflate(R.layout.layout_list_movie, null);
            }

            // Step 2 -- get references to the xml views in the row
            ImageView imageMovie = (ImageView) convertView.findViewById(R.id.image_movie);
            TextView textInfo = (TextView) convertView.findViewById(R.id.text_movie_info);
            Button buttonInfo = (Button) convertView.findViewById(R.id.button_info);

            // Step 3 -- get the new model data
            Movie mov = getItem(position);      // getting the specified coffee shop from the adapter

            // Step 4 -- load the data from the model to the view
            // TODO get source of movie
            if(mov.getLink() != null) {
                Picasso.with(imageMovie.getContext()).load(mov.getLink()).into(imageMovie);
            }
            textInfo.setText(mov.toString());

            //set tag to current position
            buttonInfo.setTag(position);

            //listener
            buttonInfo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(getActivity(), DetailActivity.class);
                    i.putExtra(EXTRA_POSITION, position);
                    startActivityForResult(i, 0);
                }
            });

            return convertView;
        }
    }
}
