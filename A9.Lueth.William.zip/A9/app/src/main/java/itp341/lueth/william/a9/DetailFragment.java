package itp341.lueth.william.a9;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import itp341.lueth.william.a9.Model.Movie;
import itp341.lueth.william.a9.Model.MovieSingleton;


/**
 * A simple {@link Fragment} subclass.
 */
public class DetailFragment extends android.support.v4.app.Fragment {
    // Instance
    private ImageView image;
    private TextView textInfo;
    private ListView listComments;
    private EditText editComment;
    private Button button_comment;

    private List<String> comments;

    public static final String ARGS_POSITION = "args_position";

    private int position;

    public DetailFragment() {
        // Required empty public constructor
    }

    //TODO store newInstance input into fragment argument
    public static DetailFragment newInstance(int position) {
        Bundle args = new Bundle();
        args.putInt(ARGS_POSITION, position);

        DetailFragment f = new DetailFragment();
        f.setArguments(args);

        return f;
    }

    //TODO read bundle argument
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();

        position = args.getInt(ARGS_POSITION);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_detail, container, false);

        // find views
        image = (ImageView) v.findViewById(R.id.image_movie);
        textInfo = (TextView) v.findViewById(R.id.text_movie_info);
        listComments = (ListView) v.findViewById(R.id.list_comment);
        editComment = (EditText) v.findViewById(R.id.edit_comment);
        button_comment = (Button) v.findViewById(R.id.button_comment);

        final Movie mov = MovieSingleton.get(getActivity()).getMovieAtPosition(position);

        // put image in

        textInfo.setText(mov.toString());

        comments = mov.getComments();

        final ArrayAdapter adapt = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, comments);
        listComments.setAdapter(adapt);

        button_comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MovieSingleton.get(getActivity()).addComment(0, mov, editComment.getText().toString());
                editComment.setText("");
                adapt.notifyDataSetChanged();
            }
        });

        return v;
    }

}
