package itp341.lueth.william.a9;


import android.app.Activity;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import itp341.lueth.william.a9.Model.Movie;
import itp341.lueth.william.a9.Model.MovieSingleton;

/**
 * A simple {@link Fragment} subclass.
 */
public class CreateFragment extends android.support.v4.app.Fragment {
    // Instance
    private EditText editTitle;
    private EditText editDesc;
    private EditText editURL;
    private Spinner spinnerGenre;
    private ImageView image;
    private Button buttonSave;

    private int position;

    public static final String ARGS_POSITION = "args_position";

    public CreateFragment() {
        // Required empty public constructor
    }

    //TODO store newInstance input into fragment argument
    public static CreateFragment newInstance() {
        Bundle args = new Bundle();

        CreateFragment f = new CreateFragment();
        f.setArguments(args);

        return f;
    }

    //TODO read bundle argument
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();

        position = args.getInt(ARGS_POSITION);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_create, container, false);

        // Find views
        editTitle = (EditText) v.findViewById(R.id.edit_title);
        editDesc = (EditText) v.findViewById(R.id.edit_description);
        editURL = (EditText) v.findViewById(R.id.edit_url);
        spinnerGenre = (Spinner) v.findViewById(R.id.spinner_genre);
        image = (ImageView) v.findViewById(R.id.image_movie);
        buttonSave = (Button) v.findViewById(R.id.button_save);

        spinnerGenre.setAdapter(ArrayAdapter.createFromResource(getActivity(), R.array.arr_genre, android.R.layout.simple_spinner_item));

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Movie mov = new Movie();
                mov.setTitle(editTitle.getText().toString());
                mov.setDesc(editDesc.getText().toString());
                mov.setLink(editURL.getText().toString());

                MovieSingleton.get(getActivity()).addMovie(mov);

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        });

        return v;
    }

}
