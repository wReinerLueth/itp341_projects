package itp341.lueth.william.final_project.Controllers;


import android.content.Intent;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import itp341.lueth.william.final_project.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Home_Fragment extends android.support.v4.app.Fragment {
    private Button buttonList;
    private Button buttonFood;
    private Button buttonMeeting;


    public Home_Fragment() {
        // Required empty public constructor
    }

    public static Home_Fragment newInstance() {
        Bundle args = new Bundle();

        Home_Fragment f = new Home_Fragment();
        f.setArguments(args);

        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        buttonList = (Button) v.findViewById(R.id.main_list);
        buttonFood = (Button) v.findViewById(R.id.main_food);
        buttonMeeting = (Button) v.findViewById(R.id.main_meeting);

        buttonList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), List_Activity.class);
                startActivityForResult(i, 0);
            }
        });

        buttonFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), Food_Activity.class);
                startActivityForResult(i, 0);
            }
        });

        buttonMeeting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), Meeting_Activity.class);
                startActivityForResult(i, 0);
            }
        });


        return v;
    }

}
