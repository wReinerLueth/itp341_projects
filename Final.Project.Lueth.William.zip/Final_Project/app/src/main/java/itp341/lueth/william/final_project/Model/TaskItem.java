package itp341.lueth.william.final_project.Model;

import com.google.android.gms.tasks.Task;

/**
 * Created by William Lueth on 12/3/2017.
 */

public class TaskItem {
    // Instance Vars
    private String instructions;
    private String hours;
    private String mins;
    private String TOD;
    private String checked;

    public TaskItem(){
        this.instructions = "Do Something Now";
        this.hours = "12";
        this.mins = "45";
        this.TOD = "pm";
    }

    public TaskItem(String instructions, String hours, String mins, String TOD) {
        this.instructions = instructions;
        this.hours = hours;
        this.mins = mins;
        this.TOD = TOD;
    }

    public TaskItem(String instructions, String hours, String mins, String TOD, String checked) {
        this.instructions = instructions;
        this.hours = hours;
        this.mins = mins;
        this.TOD = TOD;
        this.checked = checked;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String getMins() {
        return mins;
    }

    public void setMins(String mins) {
        this.mins = mins;
    }

    public String getTOD() {
        return TOD;
    }

    public void setTOD(String TOD) {
        this.TOD = TOD;
    }

    public String checkChecked() {
        return checked;
    }

    public void makeChecked(String checked) {
        this.checked = checked;
    }

    @Override
    public String toString() {
        return "Task: " + instructions +
                "\nTime: " + hours + ":" + mins + TOD;
    }
}
