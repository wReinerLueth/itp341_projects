package itp341.lueth.william.final_project.Controllers;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import itp341.lueth.william.final_project.Model.TaskItem;
import itp341.lueth.william.final_project.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class List_Fragment extends android.support.v4.app.Fragment {

    private Button buttonAdd;
    private ListView listView;

    // List Adapter
    TextView textInfo;
    CheckBox checkBox;

    private TaskAdapter listAdapter;
    private List<TaskItem> tasks = new ArrayList<>();

    private String instr;
    private String hour;
    private String mins;
    private String ToD;
    private String checked;

    private final FirebaseDatabase currBase = FirebaseDatabase.getInstance();
    private final DatabaseReference currData = currBase.getReference();
//
    public List_Fragment() {
        // Required empty public constructor
    }
//
    public static List_Fragment newInstance() {
        Bundle args = new Bundle();

        List_Fragment f = new List_Fragment();
        f.setArguments(args);

        return f;
    }
//
//
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_checklist, container, false);

        // find views
        buttonAdd = (Button) v.findViewById(R.id.button_addItem);
        buttonAdd.setBackgroundResource(R.color.colorPrimary);
        listView = (ListView) v.findViewById(R.id.list_items);

        listView.setEmptyView(inflater.inflate(R.layout.checklist_empty, null));

        currData.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                instr = dataSnapshot.child("instructions").getValue(String.class);
                hour = dataSnapshot.child("hours").getValue(String.class);
                mins = dataSnapshot.child("minutes").getValue(String.class);
                ToD = dataSnapshot.child("ToD").getValue(String.class);
//                checked = dataSnapshot.child("checked").getValue(String.class);

                TaskItem currTask = new TaskItem(instr, hour, mins, ToD);
//                TaskItem currTask = new TaskItem(instr, hour, mins, ToD, checked);
                tasks.add(currTask);
                listView.setAdapter(listAdapter);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        listAdapter = new TaskAdapter(getContext(), R.layout.checklist_list, tasks);
        listView.setAdapter(listAdapter);

        refresh();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), Add_List_Activity.class);
                startActivityForResult(i, 0);
            }
        });

        return v;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == Activity.RESULT_OK){
            refresh();
            System.out.println("Made it back");
        }
    }

    public void refresh(){
        /*
        Collections.sort(tasks, new Comparator<TaskItem>() {
            @Override
            public int compare(TaskItem taskItem, TaskItem t1) {
                if(taskItem.getTOD().equalsIgnoreCase(t1.getTOD())){
                    if(taskItem.getHours().equalsIgnoreCase(t1.getHours())){
                        if(taskItem.getMins().equalsIgnoreCase(t1.getMins())){
                            return 0;
                        }
                        return Integer.parseInt(taskItem.getMins()) - Integer.parseInt(t1.getMins());
                    }
                    return -1 * (Integer.parseInt(taskItem.getHours()) - Integer.parseInt(t1.getHours()));
                }
                if(taskItem.getTOD().equalsIgnoreCase("am")) return 1;
                else return -1;
            }
        });
        */
        listAdapter.notifyDataSetChanged();
    }

    private class TaskAdapter extends ArrayAdapter<TaskItem> {
        //do this every time
        public TaskAdapter(Context c, int resID, List<TaskItem> task){
            super(c, resID, task);
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            // Step 1 -- inflate view (row) if necessary
            if(convertView == null){        // row has NEVER BEEN CREATED
                convertView = getActivity().getLayoutInflater().inflate(R.layout.checklist_list, null);
            }

            System.out.println("--------- Hi");

            // Step 2 -- get references to the xml views in the row
            textInfo = (TextView) convertView.findViewById(R.id.task_info);
            checkBox = (CheckBox) convertView.findViewById(R.id.checkbox_list);

            // Step 3 -- get the new model data
            final TaskItem currTask = tasks.get(position);

            // Step 4 -- load the data from the model to the view
            textInfo.setText(currTask.toString());
            textInfo.setTextColor(Color.BLACK);
            //set tag to current position

            //button listener


            // TODO: 12/5/2017
            // persist checked checkboxes
/*
            if (currTask.checkChecked().equalsIgnoreCase("true")){
                if(!checkBox.isChecked()){
                    checkBox.toggle();
                }
                currTask.makeChecked("true");
            }
            else{
                if(checkBox.isChecked()){
                    checkBox.toggle();
                }
                currTask.makeChecked("false");
            }

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                    if(isChecked){
                        currTask.makeChecked("true");
                    }
                    else{
                        currTask.makeChecked("false");
                    }
                }
            });
*/

            return convertView;
        }
    }

}
