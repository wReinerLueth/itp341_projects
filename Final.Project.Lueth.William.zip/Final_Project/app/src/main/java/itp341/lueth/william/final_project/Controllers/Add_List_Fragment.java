package itp341.lueth.william.final_project.Controllers;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import itp341.lueth.william.final_project.Model.TaskItem;
import itp341.lueth.william.final_project.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class Add_List_Fragment extends android.support.v4.app.Fragment {
    // Instance Vars
    private EditText editInstructions;
    private Spinner spinHours;
    private Spinner spinMins;
    private Spinner spinTOD;
    private Button buttonAdd;

    private String hours;
    private String  mins;
    private String TOD;


    public Add_List_Fragment() {
        // Required empty public constructor
    }

    public static Add_List_Fragment newInstance() {
        Bundle args = new Bundle();

        Add_List_Fragment f = new Add_List_Fragment();
        f.setArguments(args);

        return f;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_addlist, container, false);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference parent = database.getReference();

        // find views
        editInstructions = (EditText) v.findViewById(R.id.edit_instructions);
        spinHours = (Spinner) v.findViewById(R.id.spinner_hours);
        spinMins = (Spinner) v.findViewById(R.id.spinner_minutes);
        spinTOD = (Spinner) v.findViewById(R.id.spinner_TOD);
        buttonAdd = (Button) v.findViewById(R.id.button_add_addItem);

        // Accessors for spinners

        spinHours.setAdapter(ArrayAdapter.createFromResource(getActivity(), R.array.array_hours, android.R.layout.simple_spinner_item));
        spinHours.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                hours = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                spinHours.setPrompt("Hours");
            }
        });

        spinMins.setAdapter(ArrayAdapter.createFromResource(getActivity(), R.array.array_minutes, android.R.layout.simple_spinner_item));
        spinMins.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                mins = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                spinMins.setPrompt("Minutes");
            }
        });
        spinTOD.setAdapter(ArrayAdapter.createFromResource(getActivity(), R.array.array_TOD, android.R.layout.simple_spinner_item));
        spinTOD.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                TOD = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TaskItem task = new TaskItem();
                task.setInstructions(editInstructions.getText().toString());
                task.setHours(hours);
                task.setMins(mins);
                task.setTOD(TOD);
//                task.makeChecked("false");

                // TODO: 12/3/2017
                // Add to Firebase

                writeTask(task, parent);

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        });

        return v;
    }

    private void writeTask(TaskItem inTask, DatabaseReference inBase){
        DatabaseReference newTask = inBase.push();
        newTask.child("instructions").setValue(inTask.getInstructions());
        newTask.child("hours").setValue(inTask.getHours());
        newTask.child("minutes").setValue(inTask.getMins());
        newTask.child("ToD").setValue(inTask.getTOD());
//        newTask.child("checked").setValue(inTask.checkChecked());
    }
}
