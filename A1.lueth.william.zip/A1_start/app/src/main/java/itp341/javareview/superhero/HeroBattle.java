/* EDIT THIS FILE
* William Lueth */

package itp341.javareview.superhero;

public class HeroBattle {
    public String play(){
        String str = "";
        int counter = 1;
        Superhero p1 = new Superhero("Aquaman");
        Superhero p2 = new Superhero("Wonder Woman");

        str += p1.getHeroStats() + "\n";
        str += p2.getHeroStats() + "\n";
        while(!p1.isInjured() && !p2.isInjured()){
            str += "\nROUND " + counter + "\n";
            p1.setHealthPoints(p1.getHealthPoints() - p2.getAttackValue());
            p2.setHealthPoints(p2.getHealthPoints() - p1.getAttackValue());
            str += p1.getInfo() + "\n";
            str += p2.getInfo() + "\n";
            counter++;
        }
        str += "\n";
        if(p1.isInjured() && p2.isInjured()){
            str += "It's a tie";
        }
        else if(p2.isInjured()){
            str += p1.getName() + " is the winner!";
        }
        else{
           str += p2.getName() + " is the winner!";
        }

        return str;
    }
}