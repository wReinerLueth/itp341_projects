/* EDIT THIS FILE
* William Lueth */

package itp341.javareview.superhero;

import java.util.Random;

public class Superhero{
    // Instance Variables
    private String name;
    private int healthPoints;
    private int attackValue;

    public static final int MAX_HEALTHPOINTS = 100;
    public static final int MAX_ATTACKVALUE = 20;
    public static final int MIN_HEALTHPOINTS = 0;
    public static final int MIN_ATTACKVALUE = 5;

    public Superhero(String inName){
        Random rand = new Random();
        name = inName;
        healthPoints = MAX_HEALTHPOINTS;
        attackValue = rand.nextInt(MAX_ATTACKVALUE-MIN_ATTACKVALUE)+MIN_ATTACKVALUE;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public int getAttackValue() {
        return attackValue;
    }

    public void setAttackValue(int attackValue) {
        this.attackValue = attackValue;
    }

    public String getHeroStats(){
        return "Name: " + getName()
                + "\nHealth Points: " + getHealthPoints()
                + "\nAttack Value: " + getAttackValue();
    }

    public String getInfo(){
        return getName() + " has " + getHealthPoints() + " health left.";
    }

    public boolean isInjured(){
        if(getHealthPoints() <= MIN_HEALTHPOINTS) return true;
        return false;
    }

}