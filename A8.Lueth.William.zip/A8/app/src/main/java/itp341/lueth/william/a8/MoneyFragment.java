package itp341.lueth.william.a8;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 */
public class MoneyFragment extends Fragment {
    // Instance
    private EditText editInput;
    private Spinner spinnerFrom;
    private Spinner spinnerTo;
    private Button buttonConvert;
    private TextView viewResult;

    private int from = 0;
    private int to = 0;


    public MoneyFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_money, container, false);

        registerViews(v);

        registerListeners();

        return v;
    }

    private void registerViews(View v){
        editInput = (EditText) v.findViewById(R.id.edit_exchange);
        spinnerFrom = (Spinner) v.findViewById(R.id.spinner_from);
        spinnerTo = (Spinner) v.findViewById(R.id.spinner_to);
        buttonConvert = (Button) v.findViewById(R.id.button_convert);
        viewResult = (TextView) v.findViewById(R.id.result);

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(), R.array.money_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);
    }

    private void registerListeners(){
        spinnerFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i){
                    case 0:
                        from = 1;
                        break;
                    case 1:
                        from = 2;
                        break;
                    case 2:
                        from = 3;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i){
                    case 0:
                        to = 1;
                        break;
                    case 1:
                        to = 2;
                        break;
                    case 2:
                        to = 3;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch(from){
                    case 1:
                        fromUSD(Double.parseDouble(editInput.getText().toString()), to);
                        break;
                    case 2:
                        fromYuan(Double.parseDouble(editInput.getText().toString()), to);
                        break;
                    case 3:
                        fromEuro(Double.parseDouble(editInput.getText().toString()), to);
                }
            }
        });

    }

    private void fromUSD(double input, int toConvert){
        switch(toConvert){
            case 1:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*1));
                break;
            case 2:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*6.51));
                break;
            case 3:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*0.90));
        }
    }
    private void fromYuan(double input, int toConvert){
        switch(toConvert){
            case 1:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*0.15));
                break;
            case 2:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*1));
                break;
            case 3:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*0.14));
        }
    }
    private void fromEuro(double input, int toConvert){
        switch(toConvert){
            case 1:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*1.12));
                break;
            case 2:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*7.27));
                break;
            case 3:
                viewResult.setText(getResources().getString(R.string.result) + " " + String.valueOf(input*1));
        }
    }

}
