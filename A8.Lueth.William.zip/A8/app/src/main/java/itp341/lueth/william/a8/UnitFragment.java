package itp341.lueth.william.a8;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.annotation.IdRes;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * A simple {@link Fragment} subclass.
 */
public class UnitFragment extends Fragment {
    // instance
    EditText editUnit;
    TextView textFrom;
    RadioGroup groupFrom;
    RadioButton radFromCenti;
    RadioButton radFromMeter;
    RadioButton radFromFeet;
    RadioButton radFromMile;
    RadioButton radFromKilo;
    TextView textTo;
    RadioGroup groupTo;
    RadioButton radToCenti;
    RadioButton radToMeter;
    RadioButton radToFeet;
    RadioButton radToMile;
    RadioButton radToKilo;
    Button buttonConvert;
    TextView viewResult;

    // Finals


    public UnitFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_unit, container, false);

        // find views
        registerViews(v);

        // set listeners
        registerListeners();


        return v;
    }

    private void registerViews(View v){
        editUnit = (EditText) v.findViewById(R.id.edit_unit);
        textFrom = (TextView) v.findViewById(R.id.from);
        groupFrom = (RadioGroup) v.findViewById(R.id.radio_from);
        radFromCenti = (RadioButton) v.findViewById(R.id.from_centimeters);
        radFromMeter = (RadioButton) v.findViewById(R.id.from_meters);
        radFromFeet = (RadioButton) v.findViewById(R.id.from_feet);
        radFromMile = (RadioButton) v.findViewById(R.id.from_miles);
        radFromKilo = (RadioButton) v.findViewById(R.id.from_kilomet);
        textTo = (TextView) v.findViewById(R.id.to);
        groupTo = (RadioGroup) v.findViewById(R.id.radio_to);
        radToCenti = (RadioButton) v.findViewById(R.id.to_centimeters);
        radToMeter = (RadioButton) v.findViewById(R.id.to_meters);
        radToFeet = (RadioButton) v. findViewById(R.id.to_feet);
        radToMile = (RadioButton) v.findViewById(R.id.to_miles);
        radToKilo = (RadioButton) v.findViewById(R.id.to_kilomet);
        buttonConvert = (Button) v.findViewById(R.id.button_convert);
        viewResult = (TextView) v.findViewById(R.id.result);
    }

    private void registerListeners(){
        radFromCenti.toggle();
        radToCenti.toggle();
        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int fromChecked = groupFrom.getCheckedRadioButtonId();
                int toChecked = groupTo.getCheckedRadioButtonId();

                switch(fromChecked){
                    case R.id.from_centimeters:
                        fromCentimeters(Double.parseDouble(editUnit.getText().toString()), toChecked);
                        break;
                    case R.id.from_meters:
                        fromMeters(Double.parseDouble(editUnit.getText().toString()), toChecked);
                        break;
                    case R.id.from_feet:
                        fromFeet(Double.parseDouble(editUnit.getText().toString()), toChecked);
                        break;
                    case R.id.from_miles:
                        fromMiles(Double.parseDouble(editUnit.getText().toString()), toChecked);
                        break;
                    case R.id.from_kilomet:
                        fromKilo(Double.parseDouble(editUnit.getText().toString()), toChecked);
                        break;
                }
            }
        });
    }

    private void fromCentimeters(double input, int resID){
        switch(resID){
            case R.id.to_centimeters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input*1));
                break;
            case R.id.to_meters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input*0.01));
                break;
            case R.id.to_feet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input*0.0328));
                break;
            case R.id.to_miles:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input*0.00000621));
                break;
            case R.id.to_kilomet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input*0.00001));
                break;
        }
    }
    private void fromMeters(double input, int resID) {
        switch (resID) {
            case R.id.to_centimeters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 100));
                break;
            case R.id.to_meters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 1));
                break;
            case R.id.to_feet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 3.2808));
                break;
            case R.id.to_miles:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 0.000621));
                break;
            case R.id.to_kilomet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 0.001));
                break;
        }
    }
    private void fromFeet(double input, int resID) {
        switch (resID) {
            case R.id.to_centimeters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 30.48));
                break;
            case R.id.to_meters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 0.3048));
                break;
            case R.id.to_feet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 1));
                break;
            case R.id.to_miles:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 0.000189));
                break;
            case R.id.to_kilomet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 0.000304));
                break;
        }
    }
    private void fromMiles(double input, int resID) {
        switch (resID) {
            case R.id.to_centimeters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 160934));
                break;
            case R.id.to_meters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 1609.34));
                break;
            case R.id.to_feet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 5280));
                break;
            case R.id.to_miles:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 1));
                break;
            case R.id.to_kilomet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 1.60934));
                break;
        }
    }
    private void fromKilo(double input, int resID) {
        switch (resID) {
            case R.id.to_centimeters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 100000));
                break;
            case R.id.to_meters:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 1000));
                break;
            case R.id.to_feet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 3280.84));
                break;
            case R.id.to_miles:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 0.62137));
                break;
            case R.id.to_kilomet:
                viewResult.setText(getResources().getString(R.string.result) +
                        " " + String.valueOf(input * 1));
                break;
        }
    }

}
