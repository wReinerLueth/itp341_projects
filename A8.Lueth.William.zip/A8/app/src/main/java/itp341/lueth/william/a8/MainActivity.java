package itp341.lueth.william.a8;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button buttonTip;
    Button buttonUnit;
    Button buttonExchange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final FragmentManager fm = getSupportFragmentManager();
        Fragment f = fm.findFragmentById(R.id.fragment_layout);

        final FragmentTransaction fragTransaction = fm.beginTransaction();
        fragTransaction.commit();


        buttonTip = (Button) findViewById(R.id.button_tip);
        buttonUnit = (Button) findViewById(R.id.button_unit);
        buttonExchange = (Button) findViewById(R.id.button_exchange);

        buttonTip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction tipTrans = fm.beginTransaction();
                Fragment tip = new TipFragment();
                tipTrans.replace(R.id.fragment_layout, tip);
                tipTrans.commit();
            }
        });
        buttonUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction unitTrans = fm.beginTransaction();
                Fragment unit = new UnitFragment();
                unitTrans.replace(R.id.fragment_layout, unit);
                unitTrans.commit();
            }
        });
        buttonExchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction exchangeTrans = fm.beginTransaction();
                Fragment exchange = new MoneyFragment();
                exchangeTrans.replace(R.id.fragment_layout, exchange);
                exchangeTrans.commit();
            }
        });

    }

}
